/*
 * Here comes the text of your license
 * Each line should be prefixed with  * 
 */
package ars;

/**
 *
 * @author HP
 */
public class Passenger {
    String name;
    int id;
    String address;
    long phoneno;
}
