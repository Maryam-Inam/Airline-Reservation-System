/*
 * Here comes the text of your license
 * Each line should be prefixed with  * 
 */
package ars;

/**
 *
 * @author HP
 */
public class flightFare {
    Passenger name;
    int bankId;
    long amount;
    public int selectPaymentMethod(long amount)
    {
        return 0;
    }
}
