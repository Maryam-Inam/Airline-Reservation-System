/*
 * Here comes the text of your license
 * Each line should be prefixed with  * 
 */
package ars;

/**
 *
 * @author HP
 */
public class Schedule {
    String scheduleData;
    int capacity;
    Passenger passenger;
    int currentPrice;
    String scheduleDepTime;
    String scheduleArrTime;
    int scheduleDuration;
    public void addFlight(flight detail)
    {
        
    }
    public void removeFlight(flight detail)
    {
        
    }
    public void schedule(flight flightDetail)
    {
        
    }
}
