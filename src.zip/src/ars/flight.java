/*
 * Here comes the text of your license
 * Each line should be prefixed with  * 
 */
package ars;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class flight {
    public int flightId;
    String flightno;
    String goingTime;
    String arrTime;
    String goingDate=null;
    String returnDate=null;
    int fare;
    String departureLoc;
    String arrivalLoc;
    int travelors;
    String Airline;
    String duration;
    
    public String triptyp=null;
  public int id1;
  public int id2;
  public int id3;
   public ArrayList<String> flight1=new ArrayList<String>();
  public  ArrayList<String> flight2=new ArrayList<String>();
   public ArrayList<String> flight3=new ArrayList<String>();
    
   public flight()
   {
       
   }
  public flight(int id, String fn, String gt, String arrt,String dur, String gd, String rd, String fare, String depLoc, String arrLoc, String air)
  {if(id==1)
      {
       flight1.add(air);
       flight1.add(fn);
       flight1.add(dur);
       flight1.add(fare);
       flight1.add(gt);
       flight1.add(arrt);
       flight1.add(gd);
       flight1.add(rd);
      }
      else if(id==2)
      {
       flight2.add(air);
       flight2.add(fn);
       flight2.add(dur);
       flight2.add(fare);
       flight2.add(gt);
       flight2.add(arrt);
       flight2.add(gd);
       flight2.add(rd);
      }
      else if(id==3)
      {
       flight3.add(air);
       flight3.add(fn);
       flight3.add(dur);
       flight3.add(fare);
       flight3.add(gt);
       flight3.add(arrt);
       flight3.add(gd);
       flight3.add(rd);
      }
      else
      {
          JOptionPane.showMessageDialog(null, "wrong id detected.id no: "+id);
      }
  }

  }
 