package ars;

import com.mysql.jdbc.Connection;
import java.sql.*;
import javax.swing.JOptionPane;
public class Ars {
 public static void main(String[] args) {
     
     
    }
    
}
