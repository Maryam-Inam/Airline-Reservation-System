
package ars;
public class admin {
     public static String adminname;
   public  String password;

    public admin(String password) {
        this.password = password;
    }
   
}
