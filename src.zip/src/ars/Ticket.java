/*
 * Here comes the text of your license
 * Each line should be prefixed with  * 
 */
package ars;

/**
 *
 * @author HP
 */
public class Ticket {
    int seatNo;
    int ticketNo;
    flight destinationPlace;
    flight departurePlace;
    String airportName;
}
